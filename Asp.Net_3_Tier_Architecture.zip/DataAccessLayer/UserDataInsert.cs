﻿using System;
using System.Data; // Required for using Dataset , Datatable and Sql  
using System.Configuration; // for Using Connection From Web.config 

namespace DataAccessLayer
{
    public class UserDataInsert
    {
       
       // This section will be used for creating DB connection for all DB related queries.     
        
    }
}
